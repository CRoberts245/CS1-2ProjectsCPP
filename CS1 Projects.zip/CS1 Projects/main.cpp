#include <iostream>
#include "lpcgraphics.h"
#include <stdlib.h>
using namespace std;




void vectorTask1();
void vectorTask2();
void vectorTask3();
void WaitAndClearWindow(GraphicsWindow & w);








int main()
{
    int userChoice = 0;




    cout << "1)Vectors 1" << endl;
    cout << "2)Vectors 2" << endl;
    cout << "3)Vectors 3" << endl;
    cout << "4)Display Tasks" << endl;




    cout << endl;




    cin >> userChoice;
    cin.ignore(32768, '\n');




    if(userChoice == 1)
    {
        vectorTask1();
    }
    else if(userChoice == 2)
    {
        vectorTask2();
    }
    else if(userChoice == 3)
    {
        vectorTask3();
    }
    else if (userChoice == 4)
    {
        Color red(255, 0, 0);
        Color green(0, 255, 0);
        Color blue(0, 0, 255);
        Color gray(128, 128, 128);
        Color black(0, 0, 0);
        Color yellow(255, 255, 0);
        Color white(255, 255, 255);
        Color brown(78, 52, 46);




        string message = "Sunny Day!";




        GraphicsWindow mainWindow(800, 600, "Display Task");
        mainWindow.DrawRectangle(0, 0, 800, 600, blue, true);
        mainWindow.DrawEllipse(200, 100, 100, 30, white, true);
        mainWindow.DrawEllipse(250, 75, 100, 75, white, true);
        mainWindow.DrawEllipse(300, 125, 100, 60, white, true);




        mainWindow.DrawEllipse(600, 100, 150, 60, white, true);
        mainWindow.DrawEllipse(650, 75, 80, 150, white, true);
        mainWindow.DrawEllipse(700, 125, 100, 60, white, true);




        mainWindow.DrawRectangle(100, 400, 100, 200, brown, true);




        mainWindow.DrawCircle(50, 400, 150, green, true);
        mainWindow.DrawCircle(250, 350, 125, green, true);
        mainWindow.DrawCircle(150, 200, 100, green, true);








        mainWindow.DrawCircle(800, 0, 100, yellow, true);
        mainWindow.DrawString(message, 50, 250, black, 32);
        mainWindow.Refresh();
        WaitAndClearWindow(mainWindow);


        for(int i = 10; i < 300; i += 10)
        {
            mainWindow.DrawCircle(400, 300, i, green, false);
            mainWindow.Refresh();
            mainWindow.Pause(.01);
        }


        WaitAndClearWindow(mainWindow);


        for(int i = 0; i < 580; i += 20)
        {
            mainWindow.DrawRectangle(0, i, 800, 20, Color (rand()%256, rand()%256, rand()%256), true);
        }
        mainWindow.Refresh();
        WaitAndClearWindow(mainWindow);
    }
}




void vectorTask1()
{
    vector<string> userAnswers;
    string answer;
    string searchChoice;




    while (true)
    {
        cout << "List me some movies: ";
        getline(cin, answer);
        if (answer == " ")
        {
            break;
        }
        userAnswers.push_back(answer);
    }




    cout << "Give me a search term: ";
    getline(cin, searchChoice);




    for (int i = 0; i < userAnswers.size(); i++)
    {
        if(userAnswers[i].find(searchChoice) < userAnswers[i].length())
        {
            cout << userAnswers[i] << " ";
        }
    }
}




void vectorTask2()
{
    vector<double> prices;
    double price = 0;
    double sum = 0;
    int repeats = 0;




    while(true)
    {
        cout << "Enter some prices: ";
        cin >> price;
        if(price == 0)
        {
            break;
        }
        else if(price >= 0)
        {
            prices.push_back(price);
            repeats++;
        }
    }
    for(int i = 0; i < repeats ; i++)
    {
        sum += prices[i];
    }
    cout << "Sum: " << sum << "  Average: " << sum/repeats << endl;




}
void vectorTask3()
{
    vector<string> flavors;
    vector<int> ratings;
    int repeats = 0;
    int rating = 0;




    while(true)
    {
        string flavor;
        cout << "Enter some icecream flavors: ";
        getline(cin, flavor);




        flavors.push_back(flavor);
        if(flavor == "done" || flavor == "DONE" || flavor == "Done")
        {
            break;
        }
        else
        {
            repeats++;
        }
    }
    cout << endl;
    cout << endl;




    cout << "Please enter a rating 1-10" << endl;




    for(int i = 0; i < repeats; i++)
    {
        cout << flavors[i] << ": ";
        cin >> rating;
        if(rating < 10 && rating > 0)
        {
            ratings.push_back(rating);
        }
        else
        {
            cout << "Invalid Input, try again" << endl;
            i--;
        }
    }




    cout << "-----------------" << endl;




    for(int i = 0; i < repeats; i++)
    {
        cout << left << setw(12) << flavors[i];
        for(int c = 0; c < ratings[i]; c++)
        {
            cout << "*";
        }
        cout << endl;
    }
}
void WaitAndClearWindow(GraphicsWindow & w)
{
  cout << "[Press any key to continue.]\n";
  w.WaitForKeyPress();
  w.DrawRectangle(0, 0, 800, 600, Color(0, 0, 0), true);
  w.Refresh();
}


