#include <iostream>
#include <iomanip>




using namespace std;
const int SIZE = 8;




string GetSolution();
void BlankScreen();
void PlayWordBot();
void displayBot(int tries);
string visiblePhrasePrep(string answer);
string WordChanger(string answer, string letters, string visible, int & failsLeft, string & wrongLetters);
string GetInput(string letters, string answer);




int main()
{
    PlayWordBot();
}








void PlayWordBot()
{
    string secretPhrase = GetSolution();
    string lettersGuessed = "";
    string wrongGuesses = "";
    int failuresLeft = 8;
    string visiblePhrase = visiblePhrasePrep(secretPhrase);




    BlankScreen();








    while(failuresLeft > 0 && visiblePhrase != secretPhrase)
    {
        cout << "---------------------------------" << endl;
        if(failuresLeft < 8)
        {
            cout << "Wrong Guesses: " << wrongGuesses << endl;
        }
        cout << "Guesses Left: " << failuresLeft;
        displayBot(failuresLeft);
        cout << endl;
        cout << visiblePhrase << endl;
        lettersGuessed = GetInput(lettersGuessed, secretPhrase) + lettersGuessed;




        visiblePhrase = WordChanger(secretPhrase, lettersGuessed, visiblePhrase, failuresLeft, wrongGuesses);
    }
    if(failuresLeft == 0 && visiblePhrase != secretPhrase)
    {
        cout << endl;

        displayBot(failuresLeft);

        cout << endl;




        cout << "You lose, the robot gets you!" << endl;
        cout << "The phrase was '" << secretPhrase << "'" << endl;
    }
    else
    {
        cout << endl;
        cout << "CONGRATULATIONS, YOU'VE WON!" << endl;
        cout << "The phrase was '" << secretPhrase << "'" << endl;
    }
}








void BlankScreen()
{
    for(int i = 0; i < 100; i++)
    {
        cout << endl;
    }
}








string GetSolution()
{
    string userAnswer;








    cout << "Enter a word, phrase or sentence: ";
    getline(cin, userAnswer);
    return userAnswer;








}








void displayBot(int tries)
{
    cout << endl;








    if(tries == 7)
    {
        cout << "          [o]" << endl;
        for(int i = 0; i < 7; i++)
        {
            cout << endl;
        }
    }
    else if(tries == 6)
    {
        cout << "          [o]" << endl;
        cout << "         =====" << endl;
        for(int i = 0; i < 6; i++)
        {
            cout << endl;
        }
    }
    else if(tries == 5)
    {
        cout << "          [o]" << endl;
        cout << "         =====" << endl;
        cout << "      )--|III|" << endl;
        for(int i = 0; i < 5; i++)
        {
            cout << endl;
        }
    }
    else if(tries == 4)
    {
        cout << "          [o]" << endl;
        cout << "         =====" << endl;
        cout << "      )--|III|" << endl;
        cout << "         |III|" << endl;
        for(int i = 0; i < 4; i++)
        {
            cout << endl;
        }
    }
    else if(tries == 3)
    {
        cout << "          [o]" << endl;
        cout << "         =====" << endl;
        cout << "      )--|III|" << endl;
        cout << "         |III|" << endl;
        cout << "         =====" << endl;
        for(int i = 0; i < 3; i++)
        {
            cout << endl;
        }
    }
    else if(tries == 2)
    {
        cout << "          [o]" << endl;
        cout << "         =====" << endl;
        cout << "      )--|III|" << endl;
        cout << "         |III|" << endl;
        cout << "         =====" << endl;
        cout << "          OOO" << endl;




        cout << endl;
        cout << endl;
    }
    else if(tries == 1)
    {
        cout << "          [o]" << endl;
        cout << "         =====" << endl;
        cout << "      )--|III|" << endl;
        cout << "         |III|" << endl;
        cout << "         =====" << endl;
        cout << "          OOO" << endl;
        cout << "         / | } " << endl;
        cout << endl;
    }
    else if(tries == 0)
    {
        cout << "          [o]" << endl;
        cout << "         =====" << endl;
        cout << "      )--|III|" << endl;
        cout << "         |III|" << endl;
        cout << "         =====" << endl;
        cout << "          OOO" << endl;
        cout << "         / | } " << endl;
        cout << "        @  @  @" << endl;
    }
    else
    {
        for(int i = 0; i < 8; i++)
        {
            cout << endl;
        }
    }
}




string visiblePhrasePrep(string answer)
{
    for(int c = 0; c < answer.length(); c++)
    {
        if(isalpha(answer[c]) != false)
        {
            answer[c] = '-';
        }
    }
    return answer;
}




string GetInput(string letters, string answer)
{
    string useranswer = "";
    do
    {
        cout << "Choose a letter: ";
        cin >> useranswer;
        if(useranswer.length() > 1 || !isalpha(useranswer[0]) || letters.find(useranswer) < letters.length())
        {
            cout << "Invalid Input" << endl;
        }
        else
        {
            break;
        }
    }
    while(true);
    if(answer.find(useranswer[0]) < answer.length())
    {
        cout << "There is a/an " << useranswer[0] << "." << endl;
    }
    else
    {
        cout << "There is no " << useranswer[0] << "." << endl;
    }
    return useranswer;
}




string WordChanger(string answer, string letters, string visible, int & failsLeft, string & wrongLetters)
{
    int counter = 0;
    for(int c = 0; c < answer.length(); c++)
    {
        if(visible[c] != '-')
        {


        }
        else if(letters[0] == answer[c])
        {
            counter++;
        }
        else
        {
            answer[c] = '-';
        }
    }






    if (counter == 0)
    {
        failsLeft--;
        wrongLetters += letters[0];
    }
    return answer;
}
