#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <math.h>

using namespace std;

void RollDice(int numRolls);
void FallingDistance(int dropSeconds);
void ReportVolume(string objectName, double radius);
void TriviaGuess(string trivia, string answer, int guesses);
double Diagonal(double width, double height);
double CoinFlip(int flips);
string GetMenuChoice(string item1, string item2, string item3);

int main()
{

    int userChoice = 0;

    cout << "1) RollDice" << endl;
    cout << "2) FallingDistance" << endl;
    cout << "3) ReportVolume" << endl;
    cout << "4) TriviaGuess" << endl;
    cout << "5) Diagonal" << endl;
    cout << "6) CoinFlip" << endl;
    cout << "7) GetMenuChoice" << endl;

    cout << endl;
    cout << endl;

    cout << "Make a program selection: ";
    cin >> userChoice;
    cin.ignore(32768, '\n');
    if (userChoice == 1)
    {
        int userNum = 0;

        cout << "How many times would you like to roll a 20 sided die? ";

        cin >> userNum;

        RollDice(userNum);
    }
    else if (userChoice == 2)
    {
        int seconds = 0;
        cout << "How many seconds? ";
        cin >> seconds;

        FallingDistance(seconds);
    }
    else if (userChoice == 3)
    {
        string name = "";
        double userRadius = 0.0;
        cout << "Name your round object: ";
        cin >> name;
        cout << "What is the diameter of your object? ";
        cin >> userRadius;
        userRadius = userRadius/2;

        ReportVolume(name, userRadius);
    }
    else if (userChoice == 4)
    {
        string userTrivia = "";
        string userAnswer = "";
        int userGuesses = 10;

        cout << "Enter a trivia question to test a friend!" << endl;
        getline(cin, userTrivia);

        cout << "Now enter the answer!" << endl;
        getline(cin, userAnswer);



        for(int i = 0; i < 101; i++)
        {
            cout << endl;
        }

        TriviaGuess(userTrivia, userAnswer, userGuesses);
    }
    else if (userChoice == 5)
    {
        double userHeight = 0.0;
        double userWidth = 0.0;
        cout << "What is the height of your screen? ";
        cin >> userHeight;
        cout << "What is the width of your screen? ";
        cin >> userWidth;

        if(userHeight > 0 && userWidth > 0)
        {
            cout << "The diagonal length of your screen in inches is " << Diagonal(userWidth, userHeight) << " inches.";
        }
        else
        {
            cout << "Invalid Input";
        }
    }
    else if (userChoice == 6)
    {
        double userFlips;
        cout << "How many times do you want to flip a coin? ";
        cin >> userFlips;
        cout << endl;
        if(userFlips > 0)
        {
            cout << "The percent of coins that landed on heads is " << (CoinFlip(userFlips)/userFlips)*100.0;
        }
        else
        {
            cout << "Invalid Input";
        }

    }
    else if (userChoice == 7)
    {
        cout << "You chose: " << GetMenuChoice("Pizza", "Hotdog", "Fries");
    }
}

void RollDice(int numRolls)
{
    int total = 0;
    int dieRoll = 0;
    srand(time(0));

    for(int i = 0; i < numRolls && numRolls > 0; i++)
    {
        dieRoll = rand() % 20 + 1;
        cout << dieRoll << endl;
        total += dieRoll;
    }

    cout << endl;
    cout << endl;

    cout << "The total of " << numRolls << " rolls is " << total;
}

void FallingDistance(int dropSeconds)
{
    cout << "Time" << " " << "Distance" << endl;

    double total = 0;

    for(int i = 1; i <= dropSeconds && dropSeconds > 0; i++)
    {
        cout << i << " s   ";

        total = 4.9 * (i*i);

        cout << total << endl;
    }
}

void ReportVolume (string objectName, double radius)
{
    if (radius > 0)
    {
        cout << "The " << objectName << " has a volume of " << (4/3.0)*3.14*(radius*radius*radius) << " ml.";
    }
    else
    {
        cout << "Invalid Input";
    }
}

void TriviaGuess(string trivia, string answer, int guesses)
{
    string choice = "";
    do
    {
        cout << trivia << "  (" << guesses-- << " guesses left)" << endl;
        getline(cin, choice);
    }
    while(choice != answer && guesses > 0);

    if (choice == answer)
    {
        cout << "Correct, have a nice day.";
    }
    else
    {
        cout << "Incorrect, and you're out of guesses. Goodbye!";
    }
}
double Diagonal(double width, double height)
{
    double number = sqrt((width*width)+ (height*height));
    return number;
}

double CoinFlip(int flips)
{
    srand(time(0));
    int total = 0;
    int CoinValue = 0;
    for(int i = 0; i < flips; i++)
    {
        CoinValue = rand()% 2 + 1;
        if(CoinValue == 1)
        {
            total += 1;
        }
    }
    return total;
}
string GetMenuChoice(string item1, string item2, string item3)
{
    int itemChoice = 0;
    string choice = "";

    cout << endl;
    cout << endl;

    cout << " MENU " << endl;
    cout << "------" << endl;
    cout << item1 << endl;
    cout << item2 << endl;
    cout << item3 << endl;

    cout << endl;
    cout << endl;

    do
    {

        cout << "Select an item: ";
        cin >> itemChoice;
        if(itemChoice == 1)
        {
            choice = item1;
        }
        else if(itemChoice == 2)
        {
            choice = item2;
        }
        else if (itemChoice == 3)
        {
            choice = item3;
        }
        else
        {
            cout << "Invalid Input, try again. " << endl;
        }
    }
    while(itemChoice != 1 && itemChoice != 2 && itemChoice !=3);
    return choice;
}
