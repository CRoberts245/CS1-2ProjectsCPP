#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;


void rainfall();
void tictactoe();
void file();

int main()
{
    int userChoice = 0;

    cout << "1) rainfall();" << endl;
    cout << "2) tictactoe();" << endl;
    cout << "3) file();" << endl;

    cout << endl;
    cout << endl;

    cout << "Choose a program : ";
    cin >> userChoice;
    cin.ignore(32768, '\n');

    cout << endl;
    cout << endl;

    if(userChoice == 1)
    {
        rainfall();
    }
    else if(userChoice == 2)
    {
        tictactoe();
    }
    else if(userChoice == 3)
    {
        file();
    }
}


void rainfall()
{
    string months[] = {"January", "February", "March", "April"};
    string types[] = {"Rainfall", "Average Temp", "Depth"};
    double temps[4][3];
    double total = 0.0;


    for(int i = 0; i < 4; i++)
    {
        cout << "What was the rainfall in " << months[i] << "?";
        cin >> temps[i][0];
        cout << "What was the average temp in " << months[i] << "?";
        cin >> temps[i][1];
        cout << "What was the average depth in " << months[i] << "?";
        cin >> temps[i][2];
    }
    cout << endl;
    cout << endl;


    cout << right << setw(18) << types[0];
    cout << right << setw(15) << types[1];
    cout << right << setw(7) << types[2] << endl;
    for(int i = 0; i < 4; i++)
    {
        cout << "-------------------------------------------------" << endl;
        cout << left << setw(8) << months[i];
        for(int c = 0; c < 3; c++)
        {
            cout << right << setw(10) << fixed << setprecision(2) << temps[i][c];
        }
        cout << endl;
    }
    for(int i = 0; i < 4; i++)
    {
       total += temps[i][0];
    }


    cout << "The total rainfall for the months was " << total << " inches." << endl;
    cout << endl;


    for(int i = 0; i < 4; i++)
    {
        cout << "The average temperature for  " << months[i] << " was " << temps[i][1] << " degrees" << endl;
    }


}


void tictactoe()
{
    char grid[3][3];
    int counter = 9;

    for (int r = 0; r < 3; r++)
    {
        for (int c = 0; c < 3; c++)
        {
            grid[r][c] = ' ';
        }
    }


    int turn = 1;
    cout << "Welcome to TICTACTOE!(Rows and Columns Start at 0)" << endl;

    while(counter > 0)
    {
        int columns = 0;
        int rows = 0;

        cout << "Choose a row: ";
        cin >> rows;

        cout << "Choose a column: ";

        cin >> columns;
        cout << endl;

        if(rows < 0 || rows > 2 || columns > 2 || columns < 0)
        {
            cout << "Invalid Input, please try again" << endl;
            continue;
        }
        else if(isalpha(grid[rows][columns]))
        {
            cout << "That space has already been played on. Please choose again" << endl;
            continue;
        }
        else if(turn == 1)
        {
            grid[rows][columns] = 'X';
            turn++;
            counter--;
        }
        else
        {
            grid[rows][columns] = 'O';
            counter--;
            turn--;
        }

        for(int i = 0; i  < 3 && rows > -1 && rows < 3 && columns > -1 && columns < 3 ; i++)
        {
            for(int c = 0; c < 3; c++)
            {
                cout << grid[i][c];
                if(c <= 1)
                {
                    cout << "|";
                }
            }
            cout << endl;
            if(i <= 1)
            {
                cout << "-----" << endl;
            }

        }
     }
}

void file()
{
    string filename;

    cout << "Give me a filename: ";
    getline(cin, filename);

    ifstream fin;
    fin.open(filename.c_str());

    if (fin.fail())
    {
        cout << "Sorry, I couldn't open that!" << endl;
    }
    else
    {
        cout << "Opened file successfully." << endl;
    }
    cout << endl;
    cout << endl;

    int total = 0;
    double correct = 0.0;

    do
    {
        string words;
        string answer;
        string userAnswer;


        getline(fin, words);
        getline(fin, answer);

        cout << words;

        getline(cin, userAnswer);

        if(userAnswer == answer)
        {
            cout << "Correct!" << endl;
            total++;
            correct++;
        }
        else
        {
            cout << "Incorrect." << endl;
            total++;
        }
        cout << endl;
    }
    while(fin.eof() == false);

    cout << "Your percentage of correct answers is " << fixed << setprecision(1) << (correct/total)*100 << "%";
    cout << endl;
}


