#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

int main()
{
    srand(time(0));
    int userChoice = 0;

    cout << "1)Arithmetic Tutor" << endl;
    cout << "2)Astronaut Weight Report" << endl;
    cout << "3)Speed Check" << endl;
    cout << "4)CS Club" << endl;

    cout << "" << endl;

    cin >> userChoice;

    cout << "" << endl;

    if(userChoice == 1)
    {
       int randomOne = rand()%900+100;
       int randomTwo = rand()%900+100;
       int userGuess = 0;

       cout << setw(4) << randomOne << endl;
       cout << "+" << randomTwo << endl;
       cout << "----" << endl;

       cin >> userGuess;

       if (userGuess == randomOne+randomTwo)
       {
           cout << "Correct, have a cookie";
       }
       else
       {
           cout << "Incorrect, try again later.";
       }
       cout << "" << endl;
    }
    else if (userChoice == 2)
    {
        string username = "";
        double userweight = 0.0;

        cout << "What is your last name?" << endl;
        cin >> username;

        cout << "What is your weight in pounds?" << endl;
        cin >> userweight;

        cout << "" << endl;
        cout << "" << endl;

        cout << "Mission Report: Commander " << username << endl;
        cout << "Weight on Earth: " << setw(8) << userweight << endl;
        cout << "Weight on Venus: " << setw(8) << userweight*.907 << endl;
        cout << "Weight on Mars: " << setw(9) << userweight*.377 << endl;
        cout << "Weight on Jupiter: " << userweight * 2.364 << endl;

        cout << "" << endl;
    }
    else if (userChoice == 3)
    {
        int speedlimit = 0;
        double miles = 0.0;
        int time = 0;



        cout << "What is the speed limit? ";
        cin >> speedlimit;

        cout << "How far did you drive your car in miles? ";
        cin >> miles;

        cout << "How long did it take to drive that distance in whole minutes? ";
        cin >> time;

        cout << "" << endl;
        cout << "" << endl;

        double userSpeed = miles/(time/60.0);

        cout << "Your speed was " << userSpeed << " MPH.";

        cout << "" << endl;

        if (userSpeed == speedlimit)
        {
            cout << "You were traveling exactly the speed limit.";
        }
        else if (userSpeed < speedlimit)
        {
            cout << "You were traveling under the speed limit.";
        }
        else
        {
            cout << "You were traveling over the speed limit.";
        }
        cout << "" << endl;
    }
    else if(userChoice == 4)
    {
        int age = 0;
        string userpassword = "";
        string password = "compiler";
        cout << "What is your age? ";
        cin >> age;
        cout << "What is the password? ";
        cin >> userpassword;
        if (age  < 18)
        {
            cout << "You are not old enough to enter.";
        }
        else if (age > 17 && password != userpassword)
        {
            cout << "You are old enough, but you must know the password.";
        }
        else
        {
            cout << "You may enter.";
        }
        cout << "" << endl;
    }
    else
    {
        cout << "That is not on the menu";
    }

}

