#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

int main()
{
    string username = "";
    double userWeight = 0.0;

    cout << "What is your name?" << endl;
    cin >> username;
    cout << "What is your weight in pounds?" << endl;
    cin >> userWeight;
    cout << "" << endl;
    cout << "" << endl;
}
