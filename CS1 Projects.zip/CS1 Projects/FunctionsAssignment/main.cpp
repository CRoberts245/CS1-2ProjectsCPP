#include <iostream>


using namespace std;


void HideVowels(string words);
bool IsVowel(char letter);
void SentenceAnalyzer(string sentence);
void PlayMultiNim(int stonesA, int stonesB, int stonesC);
char PickPile(int stonesNumA, int stonesNumB, int stonesNumC);
string GetName();
int getMove(int stones);
void AnnounceWinner(int turn, string name1, string name2);

int main()
{
    int userChoice = 0;
    cout << "1) HideVowels" << endl;
    cout << "2) Sentence Analyzer" << endl;
    cout << "3) PlayMultiNim" << endl;
    cout << endl;
    cout << "Choose a program function please: ";
    cin >> userChoice;
    cin.ignore(32768, '\n');




    if(userChoice == 1)
    {
        string userWords = "";


        cout << "Enter some words: ";
        getline(cin, userWords);


        cout << userWords << endl;


        cout << endl;


        HideVowels(userWords);
    }
    else if(userChoice == 2)
    {
        string userSentence = "";


        cout << "Enter a sentence: ";
        getline(cin, userSentence);


        SentenceAnalyzer(userSentence);
    }
    else if(userChoice == 3)
    {
        PlayMultiNim(3,3,3);
    }
}
void HideVowels(string words)
{
   for(int i = 0; i < words.length(); i++)
   {
       if(IsVowel(words[i]) == true)
       {
           words[i] = '*';
       }
   }
   cout << words;
}
void SentenceAnalyzer(string sentence)
{
    int totalSpaces = 0;
    int totalPunctuation = 0;
    int totalUpper = 0;
    cout << sentence[0, (sentence.length()/2)] << endl;
    for(int i = 0; i < sentence.length(); i++)
    {
        if(isupper(sentence[i]))
        {
            totalSpaces++;
        }
        else if(isspace(sentence[i]))
        {
            totalPunctuation++;
        }
        else if(ispunct(sentence[i]))
        {
            totalUpper++;
        }
    }
    cout << endl;
    cout << endl;


    cout << "Total Spaces: " << totalSpaces << endl;
    cout << "Total Punctuation: " << totalPunctuation << endl;
    cout << "Total Uppercases: " << totalUpper << endl;
}


bool IsVowel(char letter)
{
    switch (letter)
    {
    case 'a':
    case 'A':
    case 'e':
    case 'E':
    case 'i':
    case 'I':
    case 'o':
    case 'O':
    case 'u':
    case 'U':
        return true;
        break;
    default:
        return false;
    }
}


void PlayMultiNim(int stonesA, int stonesB, int stonesC)
{
    string player1 = GetName();
    string player2 = GetName();
    int whoseTurn = 1;
    int totalStones = stonesA + stonesB + stonesC;

    stonesA = 10;
    stonesB = 10;
    stonesC = 10;

    cout << endl;




    while(totalStones > 0)
    {
        cout << "Pile A: " << stonesA << " Pile B: " << stonesB << " Pile C: " << stonesC << endl;

        cout << endl;

        if(whoseTurn == 1)
        {
            cout << player1 << ",";
            char pileChoice = PickPile(stonesA, stonesB, stonesC);
            if(pileChoice == 'a' || pileChoice == 'A')
            {
                stonesA -= getMove(stonesA);
            }
            else if(pileChoice == 'b' || pileChoice == 'B')
            {
                stonesB -=getMove(stonesB);
            }
            else
            {
                stonesC -= getMove(stonesC);
            }
            whoseTurn = 2;
        }
        else if(whoseTurn == 2)
        {
            cout << player2 << ",";
            char pileChoice = PickPile(stonesA, stonesB, stonesC);
            if(pileChoice == 'a' || pileChoice == 'A')
            {
                stonesA -= getMove(stonesA);
            }
            else if(pileChoice == 'b' || pileChoice == 'B')
            {
                stonesB -=getMove(stonesB);
            }
            else
            {
                stonesC -= getMove(stonesC);
            }
            cout << endl;
            whoseTurn = 1;
        }
        totalStones = stonesA + stonesB + stonesC;
    }

    AnnounceWinner(whoseTurn, player1, player2);




}


string GetName()
{
    string name;
    cout << "Enter one player's name: ";
    getline(cin, name);
    while (name == "")
    {
        cout << "Please type a name: ";
        getline(cin, name);
    }
    return name;
}


char PickPile(int stonesNumA, int stonesNumB, int stonesNumC)
{
    char userChoice = ' ';
    if(stonesNumA == 0)
    {
        while(userChoice != 'b' && userChoice != 'B' && userChoice != 'c' && userChoice != 'C')
        {
           cout << " choose a pile(B or C): ";
           cin >> userChoice;
           if(userChoice != 'b' && userChoice != 'B' && userChoice != 'c' && userChoice != 'C')
           {
               cout << "Invalid Input, choose again." << endl;
           }
        }
    }
    else if(stonesNumB == 0)
    {
        while(userChoice != 'a' && userChoice != 'A' && userChoice != 'C' && userChoice != 'c')
        {
           cout << " choose a pile(A or C): ";
           cin >> userChoice;
           if(userChoice != 'A' && userChoice != 'a' && userChoice != 'c' && userChoice != 'C')
           {
               cout << "Invalid Input, choose again." << endl;
           }
        }
    }
    else if(stonesNumC <= 0)
    {
        while(userChoice != 'a' && userChoice != 'A' && userChoice != 'B' && userChoice != 'b')
        {
           cout << " choose a pile(A or C): ";
           cin >> userChoice;
           if(userChoice != 'a' && userChoice != 'A' && userChoice != 'B' && userChoice != 'b')
           {
               cout << "Invalid Input, choose again." << endl;
           }
        }
        stonesNumC = 0;
    }
    else
    {
       while(userChoice != 'a' && userChoice != 'A' && userChoice != 'B' && userChoice != 'b' && userChoice != 'C' && userChoice != 'c')
        {
           cout << " choose a pile(A, B, or C): ";
           cin >> userChoice;
           if(userChoice != 'a' && userChoice != 'A' && userChoice != 'B' && userChoice != 'b' && userChoice != 'c' && userChoice != 'C')
           {
               cout << "Invalid Input, choose again." << endl;
           }
        }
    }
    return userChoice;
    cout << endl;
}


int getMove(int stones)
{
    int playerMove = 0;
    do
    {
            do
            {
                cout << "Pick a number of stones to take: ";
                cin >> playerMove;
                cout << endl;
                if(playerMove > 3 || playerMove < 1 || playerMove > stones)
                {
                    cout << "Invalid Input, try again" << endl;
                }
            }
            while(playerMove > stones);
    }
    while(playerMove > 3 || playerMove < 1);

    return playerMove;
}
void AnnounceWinner(int turn, string name1, string name2)
{
    cout << endl;
    cout << endl;

    if(turn == 1)
    {
        cout << name2 << " WINS!" << endl;
    }
    else
    {
        cout << name1 << " WINS!" << endl;
    }
    cout << endl;
    cout << endl;
}
