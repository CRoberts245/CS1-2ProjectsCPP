#include <iostream>
#include <string>
#include <cmath>
#include <iomanip>
using namespace std;

int main()
{
    int userchoice = 0;

    cout << "1)Trivia" << endl;
    cout << "2)Temperature" << endl;
    cout << "3)Distance Table" << endl;
    cout << "4)Voting Counter" << endl;
    cout << "5)Price Calculator" << endl;
    cout << "6)Movie Ratings" << endl;

    cin >> userchoice;
    cin.ignore(32768, '\n');

    cout << endl;
    cout << endl;

if (userchoice == 1)
    {
        string guess = "";
        int counter = 1;
        cout << "What is the capital of California?(Sacramento)";
        getline(cin, guess);
        cout << endl;

        while(guess != "Sacramento" && guess != "sacramento")
        {
            cout << "Please try again: ";
            cout << "(Attempt #" << ++counter << ")" << endl;

            getline(cin, guess);


        }
        cout << "Correct, have a nice day!";
        cout << endl;

    }
    else if (userchoice == 2)
    {
        cout << "C" << "      F" << endl;

        for(int counter = 0; counter < 101; counter++)
        {
            cout << fixed << setprecision(1);
            cout << counter << setw(8) << (counter*9.0)/5 +32.0 << endl;
        }
    }
    else if (userchoice == 3)
    {
        int nonnegative = 0;

        do
        {


            double miles = 0.0;
            double speed = 0.0;
            double total = 0.0;
            int hourcount = 0;




            cout << "How far do you need to go in miles? ";
            cin >> miles;

            cout << "How fast are you driving in MPH?";
            cin >> speed;

            if (speed < 0 || miles < 0)
            {
                cout << "You aren't moving, try again" << endl;
                cout << endl;
                continue;
            }

            nonnegative++;

            cout << endl;
            cout <<  endl;

            cout << "Hours" << setw(9) << "Distance" << endl;

            do
            {

                cout << setw(3) << ++hourcount;
                cout << setw(7) << speed * hourcount << endl;
                total = speed * hourcount;
            }
            while(total <= miles);
        }
        while(nonnegative != 1);



    }
    else if (userchoice == 4)
    {
        string answer = "";
        int woodcounter = 0;
        int chuckcounter = 0;
        int woodchuckcounter =0;

        while(answer != "done" && answer != "DONE" && answer != "Done")
        {

            cout << "Wood, Chuck, or Woodchuck?";
            getline(cin, answer);

            if (answer == "Wood" || answer == "wood")
            {
                woodcounter++;
            }
            else if (answer == "Chuck" || answer == "chuck")
            {
                chuckcounter++;
            }
            else if (answer == "Woodchuck" || answer == "woodchuck")
            {
                woodchuckcounter++;
            }
            else
            {
                cout << "Invalid Input" << endl;
                cout << endl;
            }
        }


        cout << endl;
        cout << endl;

        cout << "Woodchucks: " << woodchuckcounter << endl;
        cout << "Woods: " << woodcounter << endl;
        cout << "Chucks: " << chuckcounter << endl;

        cout << endl;

    }
    else if (userchoice == 5)
    {
        double userprice = 0.0;
        double total = 0.0;
        setprecision(2);

        for (int counter = 1; counter <=5; counter++)
        {


            cout << "Enter price " << counter << " please(dollars): ";
            cin >> userprice;
            total += userprice*1.09;

            if(userprice < 0)
            {
                cout << "Invalid Input" << endl;
                counter = 0 ;
                total = 0;
            }

            cout << endl;
        }
        cout << "The total cost of those 5 items with tax is $" << total << "." << endl;

        cout << endl;

        cout << "The average cost of each item with tax is $" << total/5.0 << ".";

        cout << endl;
    }
    else if (userchoice == 6)
    {
        string usertitles = "";
        double stars = 0.0;
        double starstotal = 0.0;

        int star3count = 0;

    for(int counter = 1; counter < 6; ++counter)
    {

            do
            {

                cout << "Enter a media title (#" << counter << ").";
                getline(cin, usertitles);

                cout << "Enter your rating(1-5): ";
                cin >> stars;
                cin.ignore(32768, '\n');

                starstotal += stars;

                if (stars > 3)
                {
                    ++star3count;
                }
                cout << "" << endl;
            }
            while(stars < 5 && stars >= -1 && counter > 5);

            if(stars > 5 || stars < 0)
            {
                cout << endl;

                cout << "Invalid Input" << endl;

                cout << endl;

                counter = 0;
                starstotal = 0;
            }

            if(counter == 5)
            {
                cout << "" << endl;

                cout << "Your average rating is : " << starstotal/5 << endl;

                cout << "" << endl;

                cout << "You rated " << star3count << " titles above 3 stars.";

                cout << "" << endl;
            }

    }

    }
    else
    {
        cout << "Invalid Input, this program will now exit. ";
        cout << "" << endl;
    }
}

