#include <iostream>

using namespace std;

void switchExample();
void wordGame(int randnum, int randnum2);

int main()
{
    string userchoice = "";
    cout << "Would you like to play a number game?";
    getline(cin, userchoice);

    if(userchoice == "Yes" || userchoice == "yes")
    {
        switchExample();
    }
    else
    {
        string choice = "";
        cout << "How about a different number game?";
        getline(cin, choice);
        if(choice == "yes" || choice == "Yes")
        {
            double number1 = 0.0;
            double number2 = 0.0;

            cout << "Enter 2 numbers : ";
            cin >> number1;
            cin >> number2;
            wordGame(number1, number2);


        }
    }
}


void switchExample()
{
    int number = 0;

    cout << "Pick a number between 1 and 5: ";
    cin >> number;

    switch(number)
    {
    case 1:
        cout << "You win! Have a nice day.";
        break;
    case 2:
        cout << "You lose!";
        break;
    case 3:
        cout << "Not Correct!";
        break;
    default:
        cout << "Oops, incorrect!";
    }
}

void wordGame(int randnum, int randnum2)
{
    cout << "Those numbers multiplied together equal: " << randnum*randnum2;
}
