#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    int userchoice;

    cout << "Choose a program function" << endl;

    cout << endl;

    cout << "1)Box Maker" << endl;
    cout << "2)Price Calculator" << endl;
    cout << "3)Yes or No Questions" << endl;
    cout << "4)Dice Rolling" << endl;
    cout << "5)Monthly Rainfall" << endl;

    cin >> userchoice;
    cin.ignore(32768, '\n');


    cout << endl;
    cout << endl;

    if(userchoice == 1)
    {
        const int SIZE = 2;
        int dimensions[SIZE];

        cout << "Enter the dimensions of a box." << endl;
        cout << "Height: ";
        cin >> dimensions[0];
        cout << "Width: ";
        cin >> dimensions[1];


        for(int i = 0; i < dimensions[0]; i++)
        {
            for(int i = 0; i < dimensions[1]; i++)
            {
                cout << "@";
            }
            cout << endl;
        }
    }
    else if (userchoice == 2)
    {
        const int SIZE = 10;
        double prices[SIZE];
        double total = 0.0;
        int counter = 0;

        for(int i = 0; i < 10; i++)
        {
            cout << "Enter price #" << i + 1 << " : $";
            cin >> prices[i];
            total += prices[i];
        }
        cout << endl;

        cout << "Price List";

        cout << endl;

        for(int i = 0; i < 10; i++)
        {
            cout<<fixed<<setprecision(2);
            cout << "#" << i+1 << " : " << right << setw(10) << prices[i] << endl;
            if(prices[i] >= 50)
            {
               counter++;
            }
        }


        cout << endl;

        cout << "The average of your prices is $" << total/10 << endl;
        cout << "The number of prices above $50 is " << counter;

        cout << endl;
    }
    else if(userchoice == 3)
    {
        const int SIZE = 5;
        string questions[SIZE] = {"Are you from earth?", "Are you above 6 inches tall?", "Do you love CS?", "Is this program cool?", "Do you think you are cool?"};
        int counter = 0;


        for(int i = 0; i < 5 ; i++)
        {
            string answer = "";
            cout << questions[i];
            getline(cin, answer);
            if(answer == "Yes" || answer == "yes" || answer == "y" || answer == "Y")
            {
                counter++;
            }
        }
        cout << "You answered 'Yes' " << counter << " time(s).";
    }
    else if(userchoice == 4)
    {
        srand(time(0));
        int counter = 0;
        cout << "Rolling 5 20-sided dice..." << endl;

        for(int i = 0; i < 5; i++)
        {
            int roll = rand()% 20 + 1;
            cout << "Roll #" << i+1 << " : " << roll << endl;
            if(roll >= 8)
            {
                counter++;
            }
        }
        cout << "The dice rolled above 8, " << counter << " times!";
        cout << endl;

    }
    else if (userchoice == 5)
    {
        const int SIZE = 12;
        string months[SIZE] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        double rainfall[SIZE];
        double total = 0.0;

        for(int i = 0; i < SIZE; i++)
        {
            cout << "What was the total rainfall for " << months[i] << "?  ";
            cin >> rainfall[i];
            total += rainfall[i];

        }

        cout << endl;

        cout << "The total rainfall for the year is " << total << endl;
        cout << "The average monthly rainfall is " << total/12.0 << endl;

        cout << endl;
    }
    else
    {
        cout << "Invalid input, this program will now exit.";
    }






}
